Cyber4OT dataset short description
==================================
The Cyber4OT dataset contains prepared in the test-bed environment
packet traces from normal activity of OT network, as well as, 
full network attack. During recorded activity, attacker perform full
network reconnaissance and later disconnect legal Modbus TCP connection
and PLC device hijacking.

The dataset contains 96 files with more than 4,25 millions of packets.

Below short description of each file content is provided.


Cyber4OT_001 to Cyber4OT_003
============================
Normal activity, traffic gathered from central switch. Files with various 
lengths, containing: 5, 10 and 15 minutes of network traffic. 

Cyber4OT_004 to Cyber4OT_008
============================
Nmap ping scan of test bed ICS network using various modes: from 
Insane (-T5) to Sneaky (-T1). Traffic gathered from central switch. 
If scan is very long, trace is stopped after 10 minutes.

Cyber4OT_009 to Cyber4OT_013
============================
Nmap full scan of 192.168.127.6; IP taken from previous network scan. 
Traces using various modes: from Insane (-T5) to Sneaky (-T1). If scan 
is very long, trace is stopped after 10 minutes.

Cyber4OT_014 to Cyber4OT_018
============================
Nmap full scan of 192.168.127.10; IP taken from previous network scan. 
Traces using various modes: from Insane (-T5) to Sneaky (-T1). If scan 
is very long, trace is stopped after 10 minutes.

Cyber4OT_019 to Cyber4OT_023
============================
Nmap full scan of 192.168.127.11; IP taken from previous network scan. 
Traces using various modes: from Insane (-T5) to Sneaky (-T1). If scan 
is very long, trace is stopped after 10 minutes.

Cyber4OT_024 to Cyber4OT_028
============================
Nmap full scan of 192.168.127.13; IP taken from previous network scan. 
Traces using various modes: from Insane (-T5) to Sneaky (-T1). If scan 
is very long, trace is stopped after 10 minutes.

Cyber4OT_029 to Cyber4OT_033
============================
Nmap full scan of 192.168.127.20; IP taken from previous network scan. 
Traces using various modes: from Insane (-T5) to Sneaky (-T1). If scan 
is very long, trace is stopped after 10 minutes.

Cyber4OT_034 to Cyber4OT_038
============================
Nmap full scan of 192.168.127.21; IP taken from previous network scan. 
Traces using various modes: from Insane (-T5) to Sneaky (-T1). If scan 
is very long, trace is stopped after 10 minutes.

Cyber4OT_039 to Cyber4OT_043
============================
Nmap full scan of 192.168.127.23; IP taken from previous network scan. 
Traces using various modes: from Insane (-T5) to Sneaky (-T1). If scan 
is very long, trace is stopped after 10 minutes.

Cyber4OT_044 to Cyber4OT_048
============================
Nmap full scan of 192.168.127.24; IP taken from previous network scan. 
Traces using various modes: from Insane (-T5) to Sneaky (-T1). If scan 
is very long, trace is stopped after 10 minutes.

Cyber4OT_049 to Cyber4OT_053
============================
Nmap full scan of 192.168.127.30; IP taken from previous network scan. 
Traces using various modes: from Insane (-T5) to Sneaky (-T1). If scan 
is very long, trace is stopped after 10 minutes.

Cyber4OT_054 to Cyber4OT_058
============================
Nmap full scan of 192.168.127.31; IP taken from previous network scan. 
Traces using various modes: from Insane (-T5) to Sneaky (-T1). If scan 
is very long, trace is stopped after 10 minutes.

Cyber4OT_059 to Cyber4OT_063
============================
Nmap full scan of 192.168.127.33; IP taken from previous network scan. 
Traces using various modes: from Insane (-T5) to Sneaky (-T1). If scan 
is very long trace is stopped after 10 minutes.

Cyber4OT_064 to Cyber4OT_068
============================
Nmap full scan of 192.168.127.100; IP taken from previous network scan. 
Traces using various modes: from Insane (-T5) to Sneaky (-T1). If scan 
is very long, trace is stopped after 10 minutes.

Cyber4OT_069 to Cyber4OT_071
============================
Normal activity, traffic gathered from the PLC port. Files with various 
lengths: 5, 10 and 15 minutes.

Cyber4OT_072 to Cyber4OT_076
============================
Nmap ping scan of ICS network using various modes: from Insane (-T5) to 
Sneaky (-T1). Traffic gathered from the PLC port.If scan is very long, 
trace is stopped after 10 minutes.

Cyber4OT_077 to Cyber4OT_081
============================
Nmap full scan of potential PLC device; IP taken from previous network 
scan. Traces using various modes: from Insane (-T5) to Sneaky (-T1). 
If scan is very long, trace is stopped after 10 minutes.

Cyber4OT_082 to Cyber4OT_083
============================
Usage of macof utility on attackers machine, which forges frames with 
slave PLC MAC address. In effect attacker can see all traffic destined 
to the slave PLC. Second trace gathered on attacker machine.

Cyber4OT_084 to Cyber4OT_089
============================
Usage of macof and tcpkill tools. The attacker hijacks traffic from the
master PLC and remotely disconnects the Modbus TCP connection. Various
tcpkill modes are used, respectively: -3, -5 and -9. Traces with even 
number gathered from PLC port, with odd number form attacker machine.

Cyber4OT_090 to Cyber4OT_091
============================
Full successful attack. At the end attacker connects to the slave PLC 
- Modbus TCP connection is established. Second trace gathered on 
attacker machine.

Cyber4OT_092 to Cyber4OT_093
============================
Full unsuccessful attack. Before the attacker connects to the slave PLC,
legal devices reconnect to the slave PLC. In effect, the attacker program 
cannot establish a Modbus TCP connection. Second trace gathered on attacker 
machine.

Cyber4OT_094
============================
Activity after successful attack; one legitimate Modbus TCP connection
from master PLC cannot be established. Instead, in the trace appear 
hostile Modbus TCP connection. Compare with files Cyber4OT 101 to 
Cyber4OT 103.

Cyber4OT_095 to Cyber4OT_096
============================
This file contains 15 minutes of normal ICS system activity and a full 
successful attack. Second trace gathered on attacker machine.
